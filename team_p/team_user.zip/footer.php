<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2021 trando. All rights reserved.<a href="https://trando.in">Trando</a>.</p>
                                </div>
                            </div>
                        </div>