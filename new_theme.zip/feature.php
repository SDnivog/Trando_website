<div class="feature">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-md-6">
                        <div class="feature-img">
                            <img src="img/business-man.png" alt="Image">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="section-header">
                            <!-- <p>Our Feature</p> -->
                            <h2>Why Choose Us?</h2>
                        </div>
                        <p>
                            <!-- Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus  -->
                            <ul class="list-unstyled " style="font-size: larger;">
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Work According to Your choice</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Super Clean Code</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Best Forecaster</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Experts in Courses</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Digital Marketing according to your Business</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Clean Data Computing</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Satisfy Customers </li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Posters for Business</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Economical</li>
                <li class="why_opt"><span class="fa fa-arrow-right" aria-hidden="true" style="color: black;"></span> Work on Time</li>
                </ul>
                       
                        </p>
                        <div class="row counters">
                            <div class="col-6">
                                <i class="fa fa-user"></i>
                                <div class="counters-text">
                                    <h2 data-toggle="counter-up">50</h2>
                                    <p>Our Team</p>
                                </div>
                            </div>
                            <div class="col-6">
                                <i class="fa fa-users"></i>
                                <div class="counters-text">
                                    <h2 data-toggle="counter-up">10000</h2>
                                    <p>Our Clients</p>
                                </div>
                            </div>
                            <div class="col-6">
                                <i class="fa fa-check"></i>
                                <div class="counters-text">
                                    <h2 data-toggle="counter-up">30</h2>
                                    <p>Completed Projects</p>
                                </div>
                            </div>
                            <div class="col-6">
                                <i class="fa fa-running"></i>
                                <div class="counters-text">
                                    <h2 data-toggle="counter-up">10</h2>
                                    <p>Running Projects</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>