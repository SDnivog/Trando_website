<div class="navbar navbar-expand-lg bg-dark navbar-dark">
            <div class="container-fluid">
                <a href="index" class="navbar-brand"> <img src="http://trando.in/img/logo.png" alt=""> </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto">
                        <a href="index" class="nav-item nav-link active">Home</a>
                        <a href="about" class="nav-item nav-link">About</a>
                        <a href="services" class="nav-item nav-link">Service</a>
                        <!-- <a href="feature.html" class="nav-item nav-link">Feature</a>
                        <a href="advisor.html" class="nav-item nav-link">Advisor</a> -->
                        <a href="blog_page" class="nav-item nav-link">Blog</a>
                        
                        <a href="contact_us" class="nav-item nav-link">Contact</a>
                    </div>
                </div>
            </div>
        </div>