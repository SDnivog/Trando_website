<?php 
// Script to connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "cms";

$conn = mysqli_connect($servername, $username, $password, $database);

?>